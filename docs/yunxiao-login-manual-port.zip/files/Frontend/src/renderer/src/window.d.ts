import type { AuthenticationProgress, CloudJsonRequest } from '../../shared/authentication'
export {}

import type { ElectronAPI } from '@electron-toolkit/preload'
import type {
  ApplicationSchemaConfig,
  DevelopmentPlanningPageTreeNode
} from './typings'

declare global {
  interface Window {
    electron: ElectronAPI
    devAgentStudio?: {
      isElectron: boolean
      agentBaseUrl: string
      platform: string
      auth: {
        login: () => Promise<{ ok: true }>
        status: () => Promise<{ authenticated: boolean }>
        cancel: () => Promise<{ ok: true }>
        requestCloudJson: (request: CloudJsonRequest) => Promise<{ httpStatus: number; body: unknown }>
        onProgress: (listener: (progress: AuthenticationProgress) => void) => () => void
        reauthenticate: () => Promise<{ ok: true }>
      }
      settings: {
        load: () => Promise<{
          settings?: { version?: number; appearance?: { theme?: unknown } }
        }>
        saveTheme: (payload: { theme: 'dark' | 'light' }) => Promise<{ ok?: boolean }>
        onThemeChanged: (listener: (payload: { theme?: unknown }) => void) => () => void
      }
      applications: {
        load: () => Promise<{ applications?: unknown }>
        save: (applications: unknown[]) => Promise<{ ok?: boolean }>
        deleteProject: (payload: {
          applicationId: string
          workspaceRoot: string
        }) => Promise<{ ok?: boolean }>
      }
      workspace?: {
        selectDirectory: (options?: {
          title?: string
        }) => Promise<{ canceled: boolean; path?: string }>
        createProjectDirectory: (payload: {
          workspacePath: string
          applicationConfig: ApplicationSchemaConfig
        }) => Promise<{ ok?: boolean; path: string }>
        readApplication: (payload: { workspaceRoot: string }) => Promise<{ application?: unknown }>
        readUiDesigns: (payload: { workspaceRoot: string }) => Promise<{ uiDesigns: unknown }>
        writeApplication: (payload: {
          workspaceRoot: string
          application: ApplicationSchemaConfig
        }) => Promise<{ application?: unknown }>
        inspectPlanningArtifacts: (payload: { workspaceRoot: string }) => Promise<{
          ready: boolean
          hasPageDesigns: boolean
          missing: string[]
          invalid: string[]
          pages: Array<{
            key: string
            pageId: string
            label: string
            path: string
            purpose: string
            detailPlanStatus?: string
            hasDetailPlan: boolean
            designed: boolean
            taskSummary?: {
              total: number
              pending: number
              running: number
              completed: number
              failed: number
            }
          }>
          pageTree: DevelopmentPlanningPageTreeNode[]
          apiContracts: Array<{
            id: string
            label: string
            name?: string
            entityIds?: string[]
            endpoints: Array<{
              apiContractId?: string
              id: string
              name?: string
              method: string
              path: string
              summary: string
              detailPlanStatus?: string
              hasDetailPlan?: boolean
              designed?: boolean
            }>
          }>
          entities: Array<{
            id: string
            label: string
            purpose: string
            dataSourceType: string
            detailPlanStatus?: string
            hasDetailPlan: boolean
            designed: boolean
          }>
        }>
      }
      sessions?: {
        listWorkspaces: () => Promise<{ workspaces?: unknown }>
        list: (payload: {
          workspaceRoot: string
          editorMode: 'frontend' | 'backend'
        }) => Promise<{ sessions?: unknown }>
        read: (payload: {
          workspaceRoot: string
          editorMode: 'frontend' | 'backend'
          sessionId: string
        }) => Promise<{ session?: unknown }>
        create: (payload: {
          workspaceRoot: string
          workflowId: string
          editorMode: 'frontend' | 'backend'
          workbenchPhase: 'product' | 'planning' | 'development' | 'test' | 'review' | 'acceptance' | 'release'
          entryKey?: string
          title?: string
          developmentTarget?:
            | { type: 'page'; pageId: string; label: string }
            | {
                type: 'endpoint'
                apiContractId: string
                endpointId: string
                label: string
              }
          revisionContext?: unknown
        }) => Promise<{ ok?: boolean; session?: unknown }>
        save: (payload: {
          workspaceRoot: string
          session: unknown
        }) => Promise<{ ok?: boolean; session?: unknown }>
        delete: (payload: {
          workspaceRoot: string
          editorMode: 'frontend' | 'backend'
          sessionId: string
        }) => Promise<{ ok?: boolean }>
        clearWorkspace: (payload: { workspaceRoot: string }) => Promise<{ ok?: boolean }>
      }
      browser?: {
        openExternal: (url: string) => Promise<{ ok?: boolean }>
        openPreviewWindow?: (url: string) => Promise<{ ok?: boolean }>
        openReportFile?: (reportPath: string) => Promise<{ ok?: boolean }>
      }
      projectPreview?: {
        registerWorkspace: (payload: { workspaceRoot: string }) => Promise<{ ok?: boolean }>
        unregisterWorkspace: (payload: { workspaceRoot: string }) => Promise<{ ok?: boolean }>
      }
    }
  }
}
