import { stopProjectPreviewViaAgUi } from './projectPreviewControl'
import { app, shell, BrowserWindow, ipcMain, dialog, Menu, Tray, nativeImage } from 'electron'
import { join } from 'path'
import crypto from 'node:crypto'
import fs from 'node:fs/promises'
import path from 'node:path'
import icon from '../../resources/icon.png?asset'
import { PRODUCT_DISPLAY_NAME, WORKSPACE_ARTIFACT_DIR_NAME } from './branding'
import { attachUiDesignPageCode } from './uiDesignPageCode'
import { DEVAGENTSTUDIO_ENV } from './env'
import { getBackendBaseUrl, startBackendService, stopBackendService } from './backendService'
import { installDesignRuntimeProtocol, registerDesignRuntimeScheme } from './designRuntimeProtocol'
import { normalizePersistentSessionMessage } from './sessionMessageNormalization'
import { setupApplicationSettingsIpc } from './applicationSettings'
import { lstatIfPresent, movePathToTrashIfPresent } from './filesystem'
import { assertCurrentApplicationSchema, readManagedWorkspaceApplication } from './managedWorkspace'
import { endpointDesignDocumentStatus, PRODUCT_PLAN_SCHEMA_VERSION } from './planningArtifactStatus'
import {
  nextStageSessionSequence,
  stageForWorkbenchPhase,
  withStageSessionCreationLock,
  type AgentStage,
  type EditorMode,
  type WorkbenchPhase
} from './stageSessions'
import {
  clearAuthState,
  ensureDevAgentStudioDataDir,
  getAuthenticationStatus,
  revokeLocalCredentials,
  shutdownAuthentication,
  requestAuthenticatedCloud,
  getDevAgentStudioDataDir,
  hasValidAuthToken,
  loginWithYunxiao
} from './auth'

registerDesignRuntimeScheme()

// 源码开发进程使用独立数据目录，避免被已安装应用的单实例锁拦截。
if (!app.isPackaged) {
  app.setPath('userData', path.join(app.getPath('appData'), `${app.getName()}-source-dev`))
}

let mainWindow: BrowserWindow | null = null
let loginWindow: BrowserWindow | null = null
let tray: Tray | null = null
let isQuitting = false
const previewWindows = new Set<BrowserWindow>()
const launchedPreviewWorkspaces = new Map<string, string>()
const hasSingleInstanceLock = app.requestSingleInstanceLock()
let primaryStartupPromise: Promise<boolean> | null = null

/** 返回 Electron 用户数据目录中的应用列表文件路径。 */
function getApplicationsFile(): string {
  return path.join(app.getPath('userData'), 'applications.json')
}

/** 返回工作区元数据目录中的应用配置文件路径。 */
function getWorkspaceApplicationFile(workspaceRoot: string): string {
  return path.join(workspaceRoot, WORKSPACE_ARTIFACT_DIR_NAME, 'application.json')
}

/** 校验新应用目标目录未被已有应用或其他文件占用，避免创建失败后污染工作区。 */
async function assertNewProjectDirectory(projectPath: string): Promise<void> {
  const existing = await lstatIfPresent(projectPath)
  if (!existing) return
  if (!existing.isDirectory() || existing.isSymbolicLink()) {
    throw new Error('新应用项目目录必须是非符号链接目录，请选择独立的项目目录。')
  }

  const applicationFile = getWorkspaceApplicationFile(projectPath)
  const lifecycleFile = path.join(projectPath, WORKSPACE_ARTIFACT_DIR_NAME, 'application-lifecycle.json')
  if ((await lstatIfPresent(applicationFile)) || (await lstatIfPresent(lifecycleFile))) {
    throw new Error('当前工作区已属于另一个应用，请为新应用选择独立的项目目录。')
  }

  const entries = await fs.readdir(projectPath)
  if (entries.length > 0) {
    throw new Error('新应用项目目录必须是不存在或为空的独立目录。')
  }
}

type WorkbenchPageOption = {
  key: string
  pageId: string
  label: string
  path: string
  purpose: string
  designed: boolean
  detailPlanStatus?: string
  hasDetailPlan: boolean
  taskSummary?: WorkbenchTaskSummary
}

type WorkbenchTaskSummary = {
  total: number
  pending: number
  running: number
  completed: number
  failed: number
}

type WorkbenchPageTreeNode = {
  key: string
  type: 'menu' | 'page'
  label: string
  uniquePath?: string
  path?: string
  pageId?: string
  purpose?: string
  designed?: boolean
  detailPlanStatus?: string
  hasDetailPlan?: boolean
  children?: WorkbenchPageTreeNode[]
}

/** 规范化页面树节点名称，避免空白字符串在界面上显示为空占位。 */
function normalizeWorkbenchNodeLabel(value: unknown, fallback: string): string {
  const label = String(value || '').trim()
  return label || fallback
}

type WorkbenchApiContract = {
  id: string
  label: string
  name: string
  entityIds: string[]
  endpoints: Array<{
    apiContractId: string
    id: string
    name: string
    method: string
    path: string
    summary: string
    detailPlanStatus?: string
    hasDetailPlan?: boolean
    designed?: boolean
  }>
}

type WorkbenchEntityOption = {
  id: string
  label: string
  purpose: string
  dataSourceType: string
  fields?: Array<{
    name: string
    label?: string
    type: string
    required?: boolean
  }>
  detail?: Record<string, unknown>
  designed: boolean
  detailPlanStatus?: string
  hasDetailPlan: boolean
}

/** 将 API 路径统一为带前导斜杠的目录形式。 */
function normalizeApiPath(value: unknown, fallback = '/api'): string {
  const text = String(value || '').trim()
  if (!text) return fallback
  return `/${text}`.replace(/\/+/g, '/').replace(/\/$/, '') || '/'
}

/** 把数组或对象字典统一展开成记录数组，兼容不同 ProjectPlan 保存形态。 */
function recordItems(value: unknown): Array<Record<string, unknown>> {
  const items = Array.isArray(value)
    ? value
    : value && typeof value === 'object'
      ? Object.values(value as Record<string, unknown>)
      : []
  return items.filter(
    (item): item is Record<string, unknown> =>
      Boolean(item) && typeof item === 'object' && !Array.isArray(item)
  )
}

/** 判断当前计划页面节点是否为菜单目录节点。 */
function isFrontendMenuNode(record: Record<string, unknown>): boolean {
  const pageId = String(record.pageId || record.id || '').trim()
  return Array.isArray(record.children) && !pageId
}

/** 递归拍平当前计划页面，仅保留真正的业务页面叶子。 */
function flattenFrontendPageRecords(value: unknown): Array<Record<string, unknown>> {
  const flattened: Array<Record<string, unknown>> = []
  recordItems(value).forEach((record) => {
    const pageId = String(record.pageId || record.id || '').trim()
    if (pageId) flattened.push(record)
    if (Array.isArray(record.children)) {
      flattened.push(...flattenFrontendPageRecords(record.children))
    }
  })
  return flattened
}

/** 将页面 id 转成与后端详情文件一致的安全文件名。 */
function detailFileStem(value: string, prefix: string): string {
  const normalized = value.replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^[-_]+|[-_]+$/g, '')
  return `${prefix}${normalized || 'unknown'}`
}

/** 读取选中实体的外置 EntitySourceBinding，未绑定或读取失败时返回 undefined。 */
async function readEntitySourceBinding(
  workspaceRoot: string,
  entityId: string
): Promise<Record<string, unknown> | undefined> {
  const detailPath = path.join(
    workspaceRoot,
    WORKSPACE_ARTIFACT_DIR_NAME,
    'plans',
    'entities',
    `${detailFileStem(entityId, 'entity--')}.json`
  )
  try {
    const content = await fs.readFile(detailPath, 'utf8')
    if (!content.trim()) return undefined
    const parsed: unknown = JSON.parse(content)
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : undefined
  } catch {
    return undefined
  }
}

/** 从当前计划的 pages 中按页面标识收集应用大纲页面。 */
function projectPlanPages(value: unknown): Map<string, Record<string, unknown>> {
  const result = new Map<string, Record<string, unknown>>()
  if (!value || typeof value !== 'object' || Array.isArray(value)) return result
  const pages = flattenFrontendPageRecords((value as Record<string, unknown>).pages)
  pages.forEach((page) => {
    const record = page
    const pageId = String(record.id || record.pageId || '').trim()
    if (pageId) result.set(pageId, record)
  })
  return result
}

/** 从当前计划的 pages 生成工作台页面目录。 */
function projectPlanPageOptions(value: unknown): WorkbenchPageOption[] {
  return [...projectPlanPages(value).entries()].map(([pageId, record], index) => ({
    key: pageId,
    pageId,
    label: normalizeWorkbenchNodeLabel(record.name, pageId),
    path: String(record.path || '/'),
    purpose: normalizeWorkbenchNodeLabel(record.description || record.name, `页面 ${index + 1}`),
    designed: false,
    detailPlanStatus: '',
    hasDetailPlan: false
  }))
}

/** 把当前计划的 pages 递归转换为工作台可展示的页面目录树。 */
function projectPlanPageTree(value: unknown): WorkbenchPageTreeNode[] {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return []
  return buildWorkbenchPageTree((value as Record<string, unknown>).pages)
}

/** 运行时把 ProductPlan 页面事实与 TechnicalPlan references 合并为工作台视图。 */
function technicalPlanWorkbenchView(
  technicalPlan: Record<string, unknown>,
  productPlan: Record<string, unknown>
): Record<string, unknown> {
  const references = new Map(
    recordItems(technicalPlan.pages).map((page) => [
      String(page.pageId || '').trim(),
      isJsonRecord(page.references) ? page.references : {}
    ])
  )
  return {
    ...technicalPlan,
    pages: recordItems(productPlan.pages).map((page) => ({
      ...page,
      references: references.get(String(page.pageId || '').trim()) || {}
    }))
  }
}

/** 递归构造工作台侧栏使用的页面树节点。 */
function buildWorkbenchPageTree(value: unknown): WorkbenchPageTreeNode[] {
  const nodes: WorkbenchPageTreeNode[] = []
  recordItems(value).forEach((record, index) => {
    if (isFrontendMenuNode(record)) {
      const uniquePath = String(record.unique_path || '').trim()
      const key = uniquePath || `menu-${index + 1}`
      const children = buildWorkbenchPageTree(record.children)
      if (children.length === 0) return
      nodes.push({
        key,
        type: 'menu',
        label: normalizeWorkbenchNodeLabel(record.name, `菜单 ${index + 1}`),
        uniquePath,
        children
      })
      return
    }
    const pageId = String(record.pageId || record.id || '').trim()
    if (!pageId) return
    nodes.push({
      key: pageId,
      type: 'page',
      label: normalizeWorkbenchNodeLabel(record.name, pageId),
      pageId,
      path: String(record.path || '/'),
      purpose: normalizeWorkbenchNodeLabel(record.description || record.name, `页面 ${index + 1}`),
      designed: false,
      detailPlanStatus: '',
      hasDetailPlan: false
    })
  })
  return nodes
}

/** 按 base_path 合并 TechnicalPlan contracts，并保留其关联实体列表。 */
function projectPlanApiContracts(value: unknown): WorkbenchApiContract[] {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return []
  const contracts = recordItems((value as Record<string, unknown>).api_contracts)
  const groupedContracts = new Map<string, WorkbenchApiContract>()
  contracts.forEach((contract, contractIndex) => {
    const record = contract
    const contractId = String(record.id || `api-contract-${contractIndex + 1}`).trim()
    const entityIds = Array.from(
      new Set(
        (Array.isArray(record.entity_ids) ? record.entity_ids : [])
          .map((entityId) => String(entityId || '').trim())
          .filter(Boolean)
      )
    )
    const basePath = normalizeApiPath(record.base_path, `/${contractId}`)
    const endpoints = recordItems(record.endpoints)
    const group = groupedContracts.get(basePath) || {
      id: basePath,
      label: basePath,
      name: normalizeWorkbenchNodeLabel(record.name, '未命名接口分组'),
      entityIds: [],
      endpoints: []
    }
    entityIds.forEach((entityId) => {
      if (!group.entityIds.includes(entityId)) group.entityIds.push(entityId)
    })
    group.endpoints.push(
      ...endpoints.flatMap((endpoint, endpointIndex) => {
        const endpointRecord = endpoint
        const method = String(endpointRecord.method || 'GET')
          .trim()
          .toUpperCase()
        const endpointPath = String(endpointRecord.path || '').trim()
        if (!endpointPath) return []
        return [
          {
            apiContractId: contractId,
            id: String(endpointRecord.id || endpointIndex + 1),
            name: normalizeWorkbenchNodeLabel(endpointRecord.name, '未命名接口'),
            method,
            path: normalizeApiPath(endpointPath, '/'),
            summary: String(endpointRecord.summary || ''),
            designed: false,
            detailPlanStatus: '',
            hasDetailPlan: false
          }
        ]
      })
    )
    groupedContracts.set(basePath, group)
  })
  return [...groupedContracts.values()]
}

/** 从 TechnicalPlan.entities 生成工作台实体大纲选项。 */
function projectPlanEntities(value: unknown): WorkbenchEntityOption[] {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return []
  return recordItems((value as Record<string, unknown>).entities).map((record, index) => {
    const id = String(record.id || `entity-${index + 1}`).trim()
    const fields = Array.isArray(record.fields)
      ? record.fields
          .filter((field): field is Record<string, unknown> =>
            Boolean(field && typeof field === 'object' && !Array.isArray(field))
          )
          .map((field) => ({
            name: String(field.name || '').trim(),
            label:
              typeof field.label === 'string' && field.label.trim()
                ? field.label.trim()
                : undefined,
            type: String(field.type || 'text').trim(),
            required: field.required === true
          }))
          .filter((field) => Boolean(field.name))
      : []
    const sourceBinding =
      record.source_binding &&
      typeof record.source_binding === 'object' &&
      !Array.isArray(record.source_binding)
        ? (record.source_binding as Record<string, unknown>)
        : {}
    const rawDataSource = record.data_source
    const dataSourceType =
      typeof rawDataSource === 'string'
        ? rawDataSource
        : rawDataSource && typeof rawDataSource === 'object' && !Array.isArray(rawDataSource)
          ? String((rawDataSource as Record<string, unknown>).type || '')
          : ''
    return {
      id,
      label: normalizeWorkbenchNodeLabel(record.name, id),
      purpose: normalizeWorkbenchNodeLabel(record.description || record.name, `实体 ${index + 1}`),
      dataSourceType,
      ...(fields.length > 0 ? { fields } : {}),
      designed: Boolean(sourceBinding.json_path),
      detailPlanStatus: String(sourceBinding.status || record.source_binding_status || ''),
      hasDetailPlan: Boolean(sourceBinding.json_path)
    }
  })
}

/** 只根据外置 EntitySourceBinding 补充每个实体的绑定状态。 */
async function mergeWorkbenchEntityStatus(
  workspaceRoot: string,
  entities: WorkbenchEntityOption[]
): Promise<WorkbenchEntityOption[]> {
  return Promise.all(
    entities.map(async (entity) => {
      const binding = await readEntitySourceBinding(workspaceRoot, entity.id)
      const hasDetailPlan = Boolean(binding)
      return {
        ...entity,
        designed: hasDetailPlan,
        hasDetailPlan,
        ...(binding ? { detail: binding } : {})
      }
    })
  )
}

/** 初始化页面开发状态；页面不再存在独立详设产物。 */
function mergeWorkbenchPageStatus(
  pages: WorkbenchPageOption[],
  buildTaskPlan?: Record<string, unknown>
): WorkbenchPageOption[] {
  return pages.map((page) => {
    const taskSummary = pageBuildTaskSummary(buildTaskPlan, page.pageId)
    const hasBuildArtifact = Boolean(taskSummary)
    return {
      ...page,
      designed: hasBuildArtifact,
      detailPlanStatus: hasBuildArtifact ? 'generated' : '',
      hasDetailPlan: hasBuildArtifact,
      taskSummary
    }
  })
}

/** 把页面叶子的开发状态回写到页面目录树，保留菜单层级不变。 */
function mergeWorkbenchPageTreeStatus(
  pageTree: WorkbenchPageTreeNode[],
  pagesById: Map<string, WorkbenchPageOption>
): WorkbenchPageTreeNode[] {
  return pageTree.map((node) => {
    if (node.type === 'menu') {
      return {
        ...node,
        children: mergeWorkbenchPageTreeStatus(node.children || [], pagesById)
      }
    }
    const pageId = String(node.pageId || node.key || '').trim()
    const page = pagesById.get(pageId)
    return page
      ? {
          ...node,
          label: page.label,
          path: page.path,
          purpose: page.purpose,
          designed: page.designed,
          detailPlanStatus: page.detailPlanStatus,
          hasDetailPlan: page.hasDetailPlan
        }
      : node
  })
}

/** 读取正式 Build Task Plan；Markdown DAG 仅用于展示，不作为状态解析源。 */
async function readBuildTaskPlan(
  workspaceRoot: string
): Promise<Record<string, unknown> | undefined> {
  try {
    const content = await fs.readFile(
      path.join(workspaceRoot, WORKSPACE_ARTIFACT_DIR_NAME, 'plans', 'build-task-plan.json'),
      'utf8'
    )
    const value = JSON.parse(content)
    return value && typeof value === 'object' && !Array.isArray(value)
      ? (value as Record<string, unknown>)
      : undefined
  } catch {
    return undefined
  }
}

/** 按页面 Unit 及其前置 Unit 汇总正式 Build DAG 中的任务执行状态。 */
function pageBuildTaskSummary(
  buildTaskPlan: Record<string, unknown> | undefined,
  pageId: string
): WorkbenchTaskSummary | undefined {
  if (!buildTaskPlan) return undefined
  const registry =
    buildTaskPlan.task_registry &&
    typeof buildTaskPlan.task_registry === 'object' &&
    !Array.isArray(buildTaskPlan.task_registry)
      ? (buildTaskPlan.task_registry as Record<string, unknown>)
      : {}
  const graph =
    buildTaskPlan.unit_graph &&
    typeof buildTaskPlan.unit_graph === 'object' &&
    !Array.isArray(buildTaskPlan.unit_graph)
      ? (buildTaskPlan.unit_graph as Record<string, unknown>)
      : {}
  const dependencies = new Map<string, string[]>()
  recordItems(graph.edges).forEach((edge) => {
    if (edge.type !== 'depends_on') return
    const source = String(edge.from || '').trim()
    const target = String(edge.to || '').trim()
    if (source && target) dependencies.set(target, [...(dependencies.get(target) || []), source])
  })

  const selectedUnits = new Set<string>()
  const pendingUnits = [`page:${pageId}`]
  while (pendingUnits.length > 0) {
    const unitId = pendingUnits.shift()
    if (!unitId || selectedUnits.has(unitId)) continue
    selectedUnits.add(unitId)
    pendingUnits.push(...(dependencies.get(unitId) || []))
  }

  const tasks = recordItems(registry).filter((task) =>
    selectedUnits.has(String(task.unit_id || task.unitId || 'application:root'))
  )
  if (tasks.length === 0) return undefined
  const statuses = tasks.map((task) => String(task.status || 'pending'))
  return {
    total: tasks.length,
    pending: statuses.filter((status) => status === 'pending').length,
    running: statuses.filter((status) => status === 'running').length,
    completed: statuses.filter((status) => status === 'completed' || status === 'already_satisfied')
      .length,
    failed: statuses.filter((status) => status === 'failed').length
  }
}

/** 按当前版双文件、确认状态和 TechnicalPlan 指纹合并 Endpoint API 设计状态。 */
async function mergeWorkbenchApiStatus(
  workspaceRoot: string,
  contracts: WorkbenchApiContract[]
): Promise<WorkbenchApiContract[]> {
  return Promise.all(
    contracts.map(async (contract) => ({
      ...contract,
      endpoints: await Promise.all(
        contract.endpoints.map(async (endpoint) => {
          const designStatus = await endpointDesignDocumentStatus(
            workspaceRoot,
            endpoint.apiContractId,
            endpoint.id
          )
          return {
            ...endpoint,
            designed: designStatus.designed,
            detailPlanStatus: designStatus.status,
            hasDetailPlan: designStatus.designed,
            apiDesignMissingReason: designStatus.reason
          }
        })
      )
    }))
  )
}

/** 判断页面、Endpoint 或实体详细设计目录是否已有持久化产物；UI Manifest 不计入此状态。 */
async function hasPersistedDetailDesigns(workspaceRoot: string): Promise<boolean> {
  for (const directory of ['pages', 'endpoints', 'entities']) {
    try {
      const entries = await fs.readdir(path.join(workspaceRoot, WORKSPACE_ARTIFACT_DIR_NAME, 'plans', directory))
      if (entries.length > 0) return true
    } catch (error: unknown) {
      const errnoException = error as NodeJS.ErrnoException
      if (errnoException?.code === 'ENOENT') continue
      throw error
    }
  }
  return false
}

/** 校验当前正式规划产物，并从 ProductPlan/TechnicalPlan 投射工作台大纲。 */
async function inspectWorkspacePlanningArtifacts(workspaceRoot: string): Promise<{
  ready: boolean
  hasPageDesigns: boolean
  missing: string[]
  invalid: string[]
  pages: WorkbenchPageOption[]
  pageTree: WorkbenchPageTreeNode[]
  apiContracts: WorkbenchApiContract[]
  entities: WorkbenchEntityOption[]
}> {
  const artifactRoot = path.join(workspaceRoot, WORKSPACE_ARTIFACT_DIR_NAME)
  const artifacts = [
    { relativePath: 'specs/requirement-spec.md', format: 'markdown' },
    { relativePath: 'specs/requirement-spec.json', format: 'json' },
    { relativePath: 'plans/product-plan.md', format: 'markdown' },
    { relativePath: 'plans/technical-plan.md', format: 'markdown' }
  ]
  const missing: string[] = []
  const invalid: string[] = []
  let plannedPages = new Map<string, Record<string, unknown>>()
  let pageTree: WorkbenchPageTreeNode[] = []
  let apiContracts: WorkbenchApiContract[] = []
  let entities: WorkbenchEntityOption[] = []

  for (const artifact of artifacts) {
    const artifactPath = path.join(artifactRoot, artifact.relativePath)
    try {
      const content = await fs.readFile(artifactPath, 'utf8')
      if (!content.trim()) {
        invalid.push(artifact.relativePath)
        continue
      }
      if (artifact.format === 'json') {
        const value = JSON.parse(content)
        if (
          !value ||
          typeof value !== 'object' ||
          Array.isArray(value) ||
          value.confirmation_status !== 'confirmed'
        ) {
          invalid.push(artifact.relativePath)
        }
      }
    } catch (error: unknown) {
      const errnoException = error as NodeJS.ErrnoException
      if (errnoException?.code === 'ENOENT') missing.push(artifact.relativePath)
      else invalid.push(artifact.relativePath)
    }
  }

  let productPlan: Record<string, unknown> | undefined
  let technicalPlan: Record<string, unknown> | undefined
  const currentPlanArtifacts = [
    {
      relativePath: 'plans/product-plan.json',
      contractField: 'schema_version',
      contractValue: PRODUCT_PLAN_SCHEMA_VERSION
    },
    {
      relativePath: 'plans/technical-plan.json',
      contractField: 'artifact_type',
      contractValue: 'technical-plan'
    }
  ]
  // 工作台只读取当前 ProductPlan/TechnicalPlan 契约，不回退到旧计划文件。
  for (const artifact of currentPlanArtifacts) {
    try {
      const content = await fs.readFile(path.join(artifactRoot, artifact.relativePath), 'utf8')
      const plan = JSON.parse(content)
      if (
        !plan ||
        typeof plan !== 'object' ||
        Array.isArray(plan) ||
        plan[artifact.contractField] !== artifact.contractValue ||
        plan.confirmation_status !== 'confirmed'
      ) {
        invalid.push(artifact.relativePath)
        continue
      }
      if (artifact.contractValue === PRODUCT_PLAN_SCHEMA_VERSION) {
        productPlan = plan as Record<string, unknown>
      } else {
        technicalPlan = plan as Record<string, unknown>
      }
    } catch (error: unknown) {
      const errnoException = error as NodeJS.ErrnoException
      if (errnoException?.code === 'ENOENT') missing.push(artifact.relativePath)
      else invalid.push(artifact.relativePath)
    }
  }

  if (productPlan && technicalPlan) {
    const workbenchPlan = technicalPlanWorkbenchView(technicalPlan, productPlan)
    plannedPages = projectPlanPages(workbenchPlan)
    pageTree = projectPlanPageTree(workbenchPlan)
    apiContracts = projectPlanApiContracts(workbenchPlan)
  }
  entities = projectPlanEntities(technicalPlan)

  const buildTaskPlan = await readBuildTaskPlan(workspaceRoot)
  const pages = mergeWorkbenchPageStatus(
    projectPlanPageOptions({ pages: [...plannedPages.values()] }),
    buildTaskPlan
  )
  const pagesById = new Map(pages.map((page) => [page.pageId, page]))
  apiContracts = await mergeWorkbenchApiStatus(workspaceRoot, apiContracts)
  entities = await mergeWorkbenchEntityStatus(workspaceRoot, entities)
  // 首次目标选择只针对完全没有详细设计记录的工作区；UI Manifest 不会跳过该入口。
  const hasPageDesigns = await hasPersistedDetailDesigns(workspaceRoot)

  return {
    ready: missing.length === 0 && invalid.length === 0,
    hasPageDesigns,
    missing,
    invalid,
    pages,
    pageTree: mergeWorkbenchPageTreeStatus(pageTree, pagesById),
    apiContracts,
    entities
  }
}

type ChatSessionRevisionContext = {
  kind: 'formal_revision'
  sessionRole: 'design'
  formalBranch: 'design_stage_revision' | 'workbench_plan_revision'
  impactInteractionId: string
  sourceSessionId: string
  sourceConversationThreadId: string
  sourceRunId: string
  planningThreadId: string
  changeId?: string
}

type ChatSessionDevelopmentTarget =
  | { type: 'page'; pageId: string; label: string }
  | { type: 'endpoint'; apiContractId: string; endpointId: string; label: string }

type SessionWorkspaceSummary = {
  workspaceRoot: string
  name: string
  sessionCount: number
  frontendCount: number
  backendCount: number
  latestUpdatedAt: number
  latestTitle: string
}

type ChatSessionSummary = {
  id: string
  title: string
  editorMode: EditorMode
  workbenchPhase: WorkbenchPhase
  workflowId: string
  stage?: AgentStage
  sequence?: number
  entryKey?: string
  threadId: string
  developmentTarget?: ChatSessionDevelopmentTarget
  revisionContext?: ChatSessionRevisionContext
  createdAt: number
  updatedAt: number
  messageCount: number
}

type JsonRecord = Record<string, unknown>

type NormalizedChatSession = {
  id: string
  title: string
  editorMode: EditorMode
  workbenchPhase: WorkbenchPhase
  workflowId: string
  stage?: AgentStage
  sequence?: number
  entryKey?: string
  threadId: string
  developmentTarget?: ChatSessionDevelopmentTarget
  revisionContext?: ChatSessionRevisionContext
  createdAt: number
  updatedAt: number
  workspaceRoot: string
  messages: JsonRecord[]
}

/** 返回随应用发布的初始应用列表文件路径。 */
function getSeedApplicationsFile(): string {
  return path.join(__dirname, '..', 'data', 'applications.json')
}

/** 确保应用列表文件存在，并在首次运行时写入种子数据。 */
async function ensureApplicationsFile(): Promise<string> {
  const applicationsFile = getApplicationsFile()
  await fs.mkdir(path.dirname(applicationsFile), { recursive: true })

  try {
    await fs.access(applicationsFile)
    return applicationsFile
  } catch {
    // Continue and seed the file below.
  }

  let seedValue = '[]\n'
  try {
    seedValue = await fs.readFile(getSeedApplicationsFile(), 'utf8')
  } catch {
    // Keep an empty store when the seed file is not shipped.
  }

  await fs.writeFile(applicationsFile, seedValue, 'utf8')
  return applicationsFile
}

/** 校验 applications.json 索引记录，拒绝混入工作区配置副本。 */
function assertApplicationIndex(value: unknown): void {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('application index must be an object')
  }
  const record = value as Record<string, unknown>
  const allowedKeys = ['id', 'workspaceRoot', 'name', 'lastOpenedAt']
  if (
    Object.keys(record).some((key) => !allowedKeys.includes(key)) ||
    typeof record.id !== 'string' ||
    !record.id.trim() ||
    typeof record.workspaceRoot !== 'string' ||
    !record.workspaceRoot.trim() ||
    typeof record.name !== 'string' ||
    !record.name.trim() ||
    typeof record.lastOpenedAt !== 'number' ||
    !Number.isFinite(record.lastOpenedAt)
  ) {
    throw new Error('application index contains invalid fields')
  }
}

/** 读取持久化应用索引，非数组内容按空列表处理。 */
async function readApplications(): Promise<unknown[]> {
  const applicationsFile = await ensureApplicationsFile()
  const rawValue = await fs.readFile(applicationsFile, 'utf8')
  const parsed: unknown = JSON.parse(rawValue || '[]')
  return Array.isArray(parsed) ? parsed : []
}

/** 校验并持久化不含 application.json 配置副本的应用索引。 */
async function writeApplications(applications: unknown): Promise<void> {
  if (!Array.isArray(applications)) {
    throw new Error('applications must be an array')
  }
  applications.forEach(assertApplicationIndex)

  const applicationsFile = await ensureApplicationsFile()
  await fs.writeFile(applicationsFile, `${JSON.stringify(applications, null, 2)}\n`, 'utf8')
}

/** 仅将带有 DevAgent Studio 项目标识的安全工作区目录移入系统回收站。 */
async function trashProjectDirectory(workspaceRoot: unknown): Promise<void> {
  const projectRoot = resolveWorkspaceRoot(workspaceRoot)
  const protectedRoots = new Set(
    [
      path.parse(projectRoot).root,
      path.resolve(app.getPath('home')),
      path.resolve(app.getPath('userData')),
      path.resolve(getDevAgentStudioDataDir())
    ].map(pathComparisonKey)
  )
  if (protectedRoots.has(pathComparisonKey(projectRoot))) {
    throw new Error('不能删除系统、用户或 DevAgent Studio 数据目录')
  }

  const projectMetadataFile = getWorkspaceApplicationFile(projectRoot)
  const projectStats = await lstatIfPresent(projectRoot)
  if (!projectStats) return
  if (!projectStats.isDirectory() || projectStats.isSymbolicLink()) {
    throw new Error('只能删除非符号链接的项目目录')
  }

  try {
    await fs.access(projectMetadataFile)
  } catch {
    throw new Error('该目录不是由 DevAgent Studio 管理的项目，不能直接删除')
  }

  await movePathToTrashIfPresent(projectRoot, (targetPath) => shell.trashItem(targetPath))
}

/** 校验应用标识，避免 Electron 删除门禁向后端发送空目标。 */
function assertApplicationId(value: unknown): string {
  if (typeof value !== 'string' || !value.trim()) {
    throw new Error('applicationId must be a non-empty string')
  }
  return value
}

/** 调用后端统一销毁准备逻辑，并严格核对允许移入回收站的目标身份。 */
async function prepareApplicationDeletionWithBackend(
  applicationId: string,
  workspaceRoot: string
): Promise<void> {
  const response = await fetch(
    `${getBackendBaseUrl().replace(/\/$/, '')}/application-deletion/prepare`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'prepare',
        applicationId,
        workspaceRoot
      })
    }
  )
  const result = (await response.json().catch(() => undefined)) as
    | {
        applicationId?: unknown
        workspaceRoot?: unknown
        readyForTrash?: unknown
        detail?: unknown
      }
    | undefined
  if (!response.ok) {
    throw new Error(
      typeof result?.detail === 'string'
        ? result.detail
        : `Application deletion prepare failed: ${response.status}`
    )
  }
  if (
    result?.readyForTrash !== true ||
    result.applicationId !== applicationId ||
    result.workspaceRoot !== workspaceRoot
  ) {
    throw new Error('Backend did not confirm the requested application is ready for trash')
  }
}

/** 在项目目录移入回收站后通知后端释放该路径的全部删除栅栏。 */
async function completeApplicationDeletionWithBackend(
  applicationId: string,
  workspaceRoot: string
): Promise<void> {
  const response = await fetch(
    `${getBackendBaseUrl().replace(/\/$/, '')}/application-deletion/complete`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'complete',
        applicationId,
        workspaceRoot
      })
    }
  )
  const result = (await response.json().catch(() => undefined)) as
    | {
        applicationId?: unknown
        workspaceRoot?: unknown
        deletionCompleted?: unknown
        detail?: unknown
      }
    | undefined
  if (!response.ok) {
    throw new Error(
      typeof result?.detail === 'string'
        ? result.detail
        : `Application deletion completion failed: ${response.status}`
    )
  }
  if (
    result?.deletionCompleted !== true ||
    result.applicationId !== applicationId ||
    result.workspaceRoot !== workspaceRoot
  ) {
    throw new Error('Backend did not confirm the requested application deletion completion')
  }
}

/** 注册应用列表读取和保存所需的 IPC。 */
function setupApplicationStorageIpc(): void {
  ipcMain.handle('applications:load', async () => ({
    applications: await readApplications()
  }))

  ipcMain.handle('applications:save', async (_event, applications) => {
    await writeApplications(applications)
    return { ok: true }
  })

  ipcMain.handle('applications:delete-project', async (_event, payload = {}) => {
    const workspaceRoot = resolveWorkspaceRoot(payload.workspaceRoot)
    const applicationId = assertApplicationId(payload.applicationId)
    await prepareApplicationDeletionWithBackend(applicationId, workspaceRoot)
    launchedPreviewWorkspaces.delete(pathComparisonKey(workspaceRoot))
    // 先转移环境级会话；即使随后项目目录移动失败，仍可用原工作区重试删除事务。
    await movePathToTrashIfPresent(getWorkspaceSessionRoot(workspaceRoot), (targetPath) =>
      shell.trashItem(targetPath)
    )
    await trashProjectDirectory(workspaceRoot)
    await completeApplicationDeletionWithBackend(applicationId, workspaceRoot)
    return { ok: true }
  })
}

/** 校验并规范化允许由 Electron 打开的外部 HTTP 地址。 */
function normalizeExternalUrl(url: unknown): string {
  if (typeof url !== 'string') {
    throw new Error('url must be a string')
  }

  const parsedUrl = new URL(url)
  if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
    throw new Error('Only http and https URLs can be opened')
  }

  return parsedUrl.toString()
}

/** 注册系统浏览器和独立预览窗口相关 IPC。 */
function setupBrowserIpc(): void {
  ipcMain.handle('browser:open-external', async (_event, url) => {
    await shell.openExternal(normalizeExternalUrl(url))
    return { ok: true }
  })

  ipcMain.handle('browser:open-preview-window', async (_event, url) => {
    const previewWindow = new BrowserWindow({
      fullscreen: true,
      minWidth: 960,
      minHeight: 640,
      title: '全屏预览',
      backgroundColor: '#ffffff',
      webPreferences: {
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true
      }
    })

    previewWindows.add(previewWindow)
    previewWindow.once('closed', () => {
      previewWindows.delete(previewWindow)
    })
    previewWindow.webContents.setWindowOpenHandler(({ url: nextUrl }) => {
      shell.openExternal(nextUrl)
      return { action: 'deny' }
    })
    await previewWindow.loadURL(normalizeExternalUrl(url))
    previewWindow.show()
    return { ok: true }
  })

  ipcMain.handle('browser:open-report-file', async (_event, reportPath) => {
    if (typeof reportPath !== 'string' || !reportPath.trim()) {
      throw new Error('reportPath must be a non-empty string')
    }
    const resolvedPath = path.resolve(reportPath)
    const normalizedPath = resolvedPath.replaceAll('\\', '/').toLowerCase()
    if (
      !normalizedPath.includes(`/${WORKSPACE_ARTIFACT_DIR_NAME}/runtime/tests/frontend_performance/`) ||
      !normalizedPath.endsWith('.html')
    ) {
      throw new Error('Only frontend performance HTML reports can be opened')
    }
    await fs.access(resolvedPath)
    const openError = await shell.openPath(resolvedPath)
    if (openError) {
      throw new Error(openError)
    }
    return { ok: true }
  })
}

/** 记录本次 Electron 会话中手动启动或检测为运行中的项目预览工作区。 */
function setupProjectPreviewIpc(): void {
  ipcMain.handle('project-preview:register-workspace', async (_event, payload = {}) => {
    const workspaceRoot = resolveWorkspaceRoot(payload.workspaceRoot)
    launchedPreviewWorkspaces.set(pathComparisonKey(workspaceRoot), workspaceRoot)
    return { ok: true }
  })

  ipcMain.handle('project-preview:unregister-workspace', async (_event, payload = {}) => {
    const workspaceRoot = resolveWorkspaceRoot(payload.workspaceRoot)
    launchedPreviewWorkspaces.delete(pathComparisonKey(workspaceRoot))
    return { ok: true }
  })
}

/** 请求本地后端停止指定工作区的生成项目预览服务。 */
async function stopGeneratedProjectPreview(workspaceRoot: string): Promise<void> {
  await stopProjectPreviewViaAgUi(getBackendBaseUrl(), workspaceRoot)
}

/** 显式退出 Electron 前停止本次打开过的所有生成项目预览。 */
async function stopGeneratedProjectPreviewsBeforeQuit(): Promise<void> {
  const workspaces = Array.from(launchedPreviewWorkspaces.entries())
  for (const [workspaceKey, workspaceRoot] of workspaces) {
    try {
      await stopGeneratedProjectPreview(workspaceRoot)
      launchedPreviewWorkspaces.delete(workspaceKey)
    } catch (error) {
      console.error(`Failed to stop generated project preview: ${workspaceRoot}`, error)
    }
  }
}

/** 校验并返回支持的编辑器模式。 */
function assertEditorMode(value: unknown): EditorMode {
  if (value !== 'frontend' && value !== 'backend') {
    throw new Error('editorMode must be frontend or backend')
  }
  return value
}

/** 校验并返回会话所属的工作台阶段，阻止不同阶段的消息在恢复时串台。 */
function assertWorkbenchPhase(value: unknown): WorkbenchPhase {
  if (
    value !== 'product' &&
    value !== 'planning' &&
    value !== 'development' &&
    value !== 'test' &&
    value !== 'review' &&
    value !== 'acceptance' &&
    value !== 'release'
  ) {
    throw new Error('workbenchPhase must be a supported workbench phase')
  }
  return value
}

/** 校验并返回可安全用于文件名的会话标识。 */
function assertSessionId(value: unknown): string {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]+$/.test(value)) {
    throw new Error('sessionId contains invalid characters')
  }
  return value
}

/** 校验并解析工作区绝对路径。 */
function resolveWorkspaceRoot(value: unknown): string {
  if (typeof value !== 'string' || !value.trim()) {
    throw new Error('workspaceRoot must be a non-empty string')
  }
  return path.resolve(value)
}

/** 生成符合宿主文件系统大小写语义的绝对路径比较键。 */
function pathComparisonKey(value: string): string {
  const resolved = path.normalize(path.resolve(value))
  return process.platform === 'win32' ? resolved.toLowerCase() : resolved
}

/** 根据工作区名称和绝对路径哈希生成稳定的会话目录键。 */
function getWorkspaceSessionKey(workspaceRoot: unknown): string {
  const resolvedWorkspaceRoot = resolveWorkspaceRoot(workspaceRoot)
  const workspaceName =
    path
      .basename(resolvedWorkspaceRoot)
      .replace(/[^A-Za-z0-9._-]/g, '-')
      .slice(0, 80) || 'workspace'
  const workspaceHash = crypto
    .createHash('sha1')
    .update(pathComparisonKey(resolvedWorkspaceRoot))
    .digest('hex')
    .slice(0, 12)
  return `${workspaceName}-${workspaceHash}`
}

/** 返回指定工作区在环境数据目录中的会话根目录。 */
function getWorkspaceSessionRoot(workspaceRoot: unknown): string {
  return path.join(getDevAgentStudioDataDir(), 'sessions', getWorkspaceSessionKey(workspaceRoot))
}

/** 返回当前环境全部会话工作区的存储根目录。 */
function getSessionStorageRoot(): string {
  return path.join(getDevAgentStudioDataDir(), 'sessions')
}

/** 返回指定工作区和编辑器模式对应的会话目录。 */
function getSessionsDir(workspaceRoot: unknown, editorMode: unknown): string {
  return path.join(getWorkspaceSessionRoot(workspaceRoot), assertEditorMode(editorMode))
}

/** 返回校验后的单个会话文件路径。 */
function getSessionFile(workspaceRoot: unknown, editorMode: unknown, sessionId: unknown): string {
  return path.join(getSessionsDir(workspaceRoot, editorMode), `${assertSessionId(sessionId)}.json`)
}

/** 创建环境级会话目录并更新其工作区元数据。 */
async function ensureSessionsDir(workspaceRoot: unknown, editorMode: unknown): Promise<string> {
  const resolvedWorkspaceRoot = resolveWorkspaceRoot(workspaceRoot)
  const workspaceSessionRoot = getWorkspaceSessionRoot(resolvedWorkspaceRoot)
  const sessionsDir = path.join(workspaceSessionRoot, assertEditorMode(editorMode))
  await fs.mkdir(sessionsDir, { recursive: true })
  await fs.writeFile(
    path.join(workspaceSessionRoot, 'workspace.json'),
    `${JSON.stringify({ workspaceRoot: resolvedWorkspaceRoot, updatedAt: Date.now() }, null, 2)}\n`,
    'utf8'
  )
  return sessionsDir
}

/** 将规范化会话转换为列表展示所需的摘要。 */
function sessionSummary(session: NormalizedChatSession): ChatSessionSummary {
  const messages = Array.isArray(session.messages) ? session.messages : []
  return {
    id: String(session.id || ''),
    title: String(session.title || '新对话'),
    editorMode: assertEditorMode(session.editorMode),
    workbenchPhase: assertWorkbenchPhase(session.workbenchPhase),
    workflowId: session.workflowId,
    stage: session.stage,
    sequence: session.sequence,
    entryKey: session.entryKey,
    threadId: String(session.threadId || ''),
    developmentTarget: session.developmentTarget,
    revisionContext: session.revisionContext,
    createdAt: Number(session.createdAt || Date.now()),
    updatedAt: Number(session.updatedAt || Date.now()),
    messageCount: messages.length
  }
}

/** 判断未知值是否为非数组 JSON 对象。 */
function isJsonRecord(value: unknown): value is JsonRecord {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value)
}

/** 校验外部会话数据并转换为可持久化的统一结构。 */
function normalizeSession(session: unknown): NormalizedChatSession {
  if (!isJsonRecord(session)) {
    throw new Error('session must be an object')
  }

  const editorMode = assertEditorMode(session.editorMode)
  const workbenchPhase = assertWorkbenchPhase(session.workbenchPhase)
  const workflowId = normalizeSessionEndpointField(session.workflowId)
  if (!workflowId) throw new Error('workflowId must be a non-empty string')
  const stage = stageForWorkbenchPhase(workbenchPhase)
  const id = assertSessionId(session.id)
  const threadId = normalizeSessionEndpointField(session.threadId)
  if (!threadId) throw new Error('threadId must be a non-empty string')
  const messages = Array.isArray(session.messages)
    ? session.messages.filter(isJsonRecord).map(normalizePersistentSessionMessage)
    : []

  const sequence = Number(session.sequence)
  const entryKey = normalizeSessionEndpointField(session.entryKey)
  if (
    stage &&
    (session.stage !== stage || !Number.isInteger(sequence) || sequence < 1 || !entryKey)
  ) {
    throw new Error('stage session identity is incomplete')
  }
  if (!stage && (session.stage || session.sequence || session.entryKey)) {
    throw new Error('non-stage session cannot declare stage identity')
  }
  const developmentTarget = normalizeDevelopmentTarget(session.developmentTarget)
  if (session.developmentTarget !== undefined && !developmentTarget) {
    throw new Error('session developmentTarget is invalid')
  }
  if (developmentTarget && workbenchPhase !== 'development') {
    throw new Error('session developmentTarget requires DEVELOPMENT phase')
  }
  const revisionContext = normalizeSessionRevisionContext(session.revisionContext)
  return {
    id,
    title: String(session.title || '新对话'),
    editorMode,
    workbenchPhase,
    workflowId,
    ...(stage ? { stage, sequence, entryKey } : {}),
    threadId,
    ...(developmentTarget ? { developmentTarget } : {}),
    ...(revisionContext ? { revisionContext } : {}),
    createdAt: Number(session.createdAt || Date.now()),
    updatedAt: Number(session.updatedAt || Date.now()),
    workspaceRoot: typeof session.workspaceRoot === 'string' ? session.workspaceRoot : '',
    messages
  }
}

/** 严格规范化当前契约支持的页面或 Endpoint 会话目标。 */
function normalizeDevelopmentTarget(value: unknown): ChatSessionDevelopmentTarget | undefined {
  if (!isJsonRecord(value)) return undefined
  const label = normalizeSessionEndpointField(value.label)
  if (value.type === 'page') {
    const pageId = normalizeSessionEndpointField(value.pageId)
    return pageId && label ? { type: 'page', pageId, label } : undefined
  }
  if (value.type === 'endpoint') {
    const apiContractId = normalizeSessionEndpointField(value.apiContractId)
    const endpointId = normalizeSessionEndpointField(value.endpointId)
    return apiContractId && endpointId && label
      ? { type: 'endpoint', apiContractId, endpointId, label }
      : undefined
  }
  return undefined
}

/** 比较规范化后的页面或 Endpoint 目标，阻止持久化会话被改绑。 */
function sameDevelopmentTarget(
  left: ChatSessionDevelopmentTarget | undefined,
  right: ChatSessionDevelopmentTarget | undefined
): boolean {
  if (!left || !right) return !left && !right
  if (left.type !== right.type) return false
  return left.type === 'page'
    ? left.pageId === (right.type === 'page' ? right.pageId : '')
    : right.type === 'endpoint' &&
        left.apiContractId === right.apiContractId &&
        left.endpointId === right.endpointId
}

/** 规范化接口会话标识，避免空字符串污染持久化索引。 */
function normalizeSessionEndpointField(value: unknown): string | undefined {
  const text = typeof value === 'string' ? value.trim() : ''
  return text || undefined
}

/** 规范化二次修改会话的来源、业务 change 与原规划 checkpoint 身份。 */
function normalizeSessionRevisionContext(value: unknown): ChatSessionRevisionContext | undefined {
  if (!isJsonRecord(value) || value.kind !== 'formal_revision') return undefined
  const sessionRole = normalizeSessionEndpointField(value.sessionRole)
  const formalBranch = normalizeSessionEndpointField(value.formalBranch)
  const impactInteractionId = normalizeSessionEndpointField(value.impactInteractionId)
  const sourceSessionId = normalizeSessionEndpointField(value.sourceSessionId)
  const sourceConversationThreadId = normalizeSessionEndpointField(value.sourceConversationThreadId)
  const sourceRunId = normalizeSessionEndpointField(value.sourceRunId)
  const planningThreadId = normalizeSessionEndpointField(value.planningThreadId)
  const changeId = normalizeSessionEndpointField(value.changeId)
  if (
    sessionRole !== 'design' ||
    !['design_stage_revision', 'workbench_plan_revision'].includes(formalBranch || '') ||
    !impactInteractionId ||
    !sourceSessionId ||
    !sourceConversationThreadId ||
    !sourceRunId ||
    !planningThreadId
  ) {
    return undefined
  }
  return {
    kind: 'formal_revision',
    sessionRole: 'design',
    formalBranch: formalBranch as ChatSessionRevisionContext['formalBranch'],
    impactInteractionId,
    sourceSessionId,
    sourceConversationThreadId,
    sourceRunId,
    planningThreadId,
    ...(changeId ? { changeId } : {})
  }
}

async function readSessionSummariesFromDir(
  sessionsDir: string,
  editorMode: EditorMode
): Promise<ChatSessionSummary[]> {
  let entries
  try {
    entries = await fs.readdir(sessionsDir, { withFileTypes: true })
  } catch {
    return []
  }

  const sessions: ChatSessionSummary[] = []
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith('.json')) continue
    try {
      const rawValue = await fs.readFile(path.join(sessionsDir, entry.name), 'utf8')
      const session = normalizeSession(JSON.parse(rawValue || '{}'))
      if (session.editorMode !== editorMode) continue
      sessions.push(sessionSummary(session))
    } catch {
      // Ignore malformed session files so one bad record does not hide the workspace.
    }
  }
  return sessions
}

/** 读取工作区当前契约下的全部会话，供阶段幂等与 sequence 分配使用。 */
async function readWorkspaceSessions(workspaceRoot: string): Promise<NormalizedChatSession[]> {
  const sessions: NormalizedChatSession[] = []
  for (const editorMode of ['frontend', 'backend'] as const) {
    const sessionsDir = getSessionsDir(workspaceRoot, editorMode)
    let entries
    try {
      entries = await fs.readdir(sessionsDir, { withFileTypes: true })
    } catch {
      continue
    }
    for (const entry of entries) {
      if (!entry.isFile() || !entry.name.endsWith('.json')) continue
      try {
        const rawValue = await fs.readFile(path.join(sessionsDir, entry.name), 'utf8')
        const session = normalizeSession(JSON.parse(rawValue || '{}'))
        if (session.editorMode === editorMode) sessions.push(session)
      } catch {
        // 当前契约不读取旧格式或损坏记录。
      }
    }
  }
  return sessions
}

/** 创建当前会话记录；前三阶段在锁内分配新 Thread 与全局递增 sequence。 */
async function createChatSession(
  workspaceRootValue: unknown,
  inputValue: unknown
): Promise<NormalizedChatSession> {
  if (!isJsonRecord(inputValue)) throw new Error('session create input must be an object')
  const workspaceRoot = resolveWorkspaceRoot(workspaceRootValue)
  const editorMode = assertEditorMode(inputValue.editorMode)
  const workbenchPhase = assertWorkbenchPhase(inputValue.workbenchPhase)
  const workflowId = normalizeSessionEndpointField(inputValue.workflowId)
  if (!workflowId) throw new Error('workflowId must be a non-empty string')
  const stage = stageForWorkbenchPhase(workbenchPhase)
  const entryKey = stage
    ? normalizeSessionEndpointField(inputValue.entryKey) || `session:${crypto.randomUUID()}`
    : undefined
  const lockKey = `${pathComparisonKey(workspaceRoot)}:${workflowId}:${stage || workbenchPhase}`

  return withStageSessionCreationLock(lockKey, async () => {
    const existingSessions = await readWorkspaceSessions(workspaceRoot)
    if (stage && entryKey) {
      const existing = existingSessions.find(
        (session) =>
          session.workflowId === workflowId &&
          session.stage === stage &&
          session.entryKey === entryKey
      )
      if (existing) {
        const identityMatches =
          existing.editorMode === editorMode && existing.workbenchPhase === workbenchPhase
        if (!identityMatches) throw new Error('entryKey is already bound to another phase session')
        return existing
      }
    }
    const sequence = stage
      ? nextStageSessionSequence(existingSessions, workflowId, stage)
      : undefined
    const now = Date.now()
    const session = normalizeSession({
      ...inputValue,
      id: crypto.randomUUID(),
      workflowId,
      workbenchPhase,
      editorMode,
      ...(stage ? { stage, sequence, entryKey } : {}),
      threadId: crypto.randomUUID(),
      workspaceRoot,
      messages: [],
      createdAt: now,
      updatedAt: now
    })
    await ensureSessionsDir(workspaceRoot, editorMode)
    await fs.writeFile(
      getSessionFile(workspaceRoot, editorMode, session.id),
      `${JSON.stringify(session, null, 2)}\n`,
      'utf8'
    )
    return session
  })
}

async function listSessionWorkspaces(): Promise<SessionWorkspaceSummary[]> {
  const sessionsRoot = getSessionStorageRoot()
  let entries
  try {
    entries = await fs.readdir(sessionsRoot, { withFileTypes: true })
  } catch {
    return []
  }

  const workspaces: SessionWorkspaceSummary[] = []
  for (const entry of entries) {
    if (!entry.isDirectory()) continue

    const workspaceSessionRoot = path.join(sessionsRoot, entry.name)
    let workspaceRoot: string
    try {
      const rawWorkspace = await fs.readFile(
        path.join(workspaceSessionRoot, 'workspace.json'),
        'utf8'
      )
      const workspaceRecord = JSON.parse(rawWorkspace || '{}')
      workspaceRoot = resolveWorkspaceRoot(workspaceRecord.workspaceRoot)
    } catch {
      continue
    }

    const frontendSessions = await readSessionSummariesFromDir(
      path.join(workspaceSessionRoot, 'frontend'),
      'frontend'
    )
    const backendSessions = await readSessionSummariesFromDir(
      path.join(workspaceSessionRoot, 'backend'),
      'backend'
    )
    const allSessions = [...frontendSessions, ...backendSessions].sort(
      (a, b) => b.updatedAt - a.updatedAt
    )
    if (allSessions.length === 0) continue

    const latestSession = allSessions[0]
    workspaces.push({
      workspaceRoot,
      name: path.basename(workspaceRoot) || workspaceRoot,
      sessionCount: allSessions.length,
      frontendCount: frontendSessions.length,
      backendCount: backendSessions.length,
      latestUpdatedAt: latestSession.updatedAt,
      latestTitle: latestSession.title
    })
  }

  return workspaces.sort((a, b) => b.latestUpdatedAt - a.latestUpdatedAt)
}

/** 注册工作区读取、选择和项目创建相关 IPC。 */
function setupWorkspaceIpc(): void {
  ipcMain.handle('workspace:inspect-planning-artifacts', async (_event, payload = {}) => {
    const workspaceRoot = resolveWorkspaceRoot(payload.workspaceRoot)
    return inspectWorkspacePlanningArtifacts(workspaceRoot)
  })

  // 直接读取工作区 specs/ui-designs.json，供前端轮询后台生成池进度。
  // 绕过 Graph run（同 thread 不能并发），避免 no-op resume 被 checkpoint 约束吞掉。
  //
  // 顺带回填每页的 `code`：正式 manifest 刻意只存 `code_path` 不存源码（运行时数据），
  // 但确认界面要靠它渲染预览、「查看设计稿」按钮也按它判可用性。不回填的话，重新打开
  // 工作区后每一页都点不开 —— 本轮新生成的和从上一轮继承来的一视同仁。
  ipcMain.handle('workspace:read-ui-designs', async (_event, payload = {}) => {
    const workspaceRoot = resolveWorkspaceRoot(payload.workspaceRoot)
    const uiDesignsPath = path.join(workspaceRoot, WORKSPACE_ARTIFACT_DIR_NAME, 'specs', 'ui-designs.json')
    try {
      const content = await fs.readFile(uiDesignsPath, 'utf8')
      const parsed = JSON.parse(content)
      return { uiDesigns: await attachUiDesignPageCode(workspaceRoot, parsed) }
    } catch {
      return { uiDesigns: null }
    }
  })

  ipcMain.handle('workspace:read-application', async (_event, payload = {}) => {
    const workspaceRoot = resolveWorkspaceRoot(payload.workspaceRoot)
    const applicationConfig = await readManagedWorkspaceApplication(workspaceRoot)
    return { application: applicationConfig }
  })

  ipcMain.handle('workspace:write-application', async (_event, payload = {}) => {
    const workspaceRoot = resolveWorkspaceRoot(payload.workspaceRoot)
    if (
      !payload.application ||
      typeof payload.application !== 'object' ||
      Array.isArray(payload.application)
    ) {
      throw new Error('application must be an object')
    }
    const currentApplication = await readManagedWorkspaceApplication(workspaceRoot)
    const nextApplication = { ...(payload.application as Record<string, unknown>) }
    // 只有实际配置变化才递增版本，避免打开或刷新应用时制造过期规划产物。
    if (JSON.stringify(currentApplication) !== JSON.stringify(nextApplication)) {
      nextApplication.configRevision = Number(currentApplication.configRevision) + 1
    }
    assertCurrentApplicationSchema(nextApplication)
    const applicationFile = getWorkspaceApplicationFile(workspaceRoot)
    await fs.writeFile(applicationFile, `${JSON.stringify(nextApplication, null, 2)}\n`, 'utf8')
    return { application: await readManagedWorkspaceApplication(workspaceRoot) }
  })

  ipcMain.handle('workspace:select-directory', async (_event, options = {}) => {
    const result = await dialog.showOpenDialog(mainWindow!, {
      title: typeof options.title === 'string' ? options.title : '选择工作目录',
      properties: ['openDirectory', 'createDirectory']
    })

    return {
      canceled: result.canceled,
      path: result.filePaths[0]
    }
  })

  ipcMain.handle('workspace:create-project-directory', async (_event, payload = {}) => {
    if (typeof payload.workspacePath !== 'string' || !payload.workspacePath.trim()) {
      throw new Error('workspacePath must be a non-empty string')
    }
    if (
      !payload.applicationConfig ||
      typeof payload.applicationConfig !== 'object' ||
      Array.isArray(payload.applicationConfig)
    ) {
      throw new Error('applicationConfig must be an object')
    }
    assertCurrentApplicationSchema(payload.applicationConfig as Record<string, unknown>)

    const projectPath = path.resolve(payload.workspacePath)
    await assertNewProjectDirectory(projectPath)
    if (!(await lstatIfPresent(projectPath))) {
      await fs.mkdir(projectPath, { recursive: false })
    }
    const applicationFile = getWorkspaceApplicationFile(projectPath)
    await fs.mkdir(path.dirname(applicationFile), { recursive: true })
    await fs.writeFile(applicationFile, `${JSON.stringify(payload.applicationConfig, null, 2)}\n`, {
      encoding: 'utf8',
      flag: 'wx'
    })

    return {
      ok: true,
      path: projectPath
    }
  })
}

function setupSessionStorageIpc(): void {
  ipcMain.handle('sessions:list-workspaces', async () => ({
    workspaces: await listSessionWorkspaces()
  }))

  ipcMain.handle('sessions:list', async (_event, payload = {}) => {
    const workspaceRoot = resolveWorkspaceRoot(payload.workspaceRoot)
    const editorMode = assertEditorMode(payload.editorMode)
    const sessionsDir = await ensureSessionsDir(workspaceRoot, editorMode)

    const entries = await fs.readdir(sessionsDir, { withFileTypes: true })
    const sessions: ChatSessionSummary[] = []
    for (const entry of entries) {
      if (!entry.isFile() || !entry.name.endsWith('.json')) continue
      try {
        const rawValue = await fs.readFile(path.join(sessionsDir, entry.name), 'utf8')
        const session = normalizeSession(JSON.parse(rawValue || '{}'))
        sessions.push(sessionSummary(session))
      } catch {
        // Ignore malformed session files so one bad record does not hide the full history.
      }
    }

    sessions.sort((a, b) => b.updatedAt - a.updatedAt)
    return { sessions }
  })

  ipcMain.handle('sessions:read', async (_event, payload = {}) => {
    const sessionFile = getSessionFile(payload.workspaceRoot, payload.editorMode, payload.sessionId)
    const rawValue = await fs.readFile(sessionFile, 'utf8')
    return { session: normalizeSession(JSON.parse(rawValue || '{}')) }
  })

  ipcMain.handle('sessions:create', async (_event, payload = {}) => {
    const session = await createChatSession(payload.workspaceRoot, payload.session)
    return { ok: true, session }
  })

  ipcMain.handle('sessions:save', async (_event, payload = {}) => {
    const workspaceRoot = resolveWorkspaceRoot(payload.workspaceRoot)
    const session = normalizeSession({
      ...payload.session,
      workspaceRoot
    })
    const sessionFile = getSessionFile(workspaceRoot, session.editorMode, session.id)
    const existing = normalizeSession(JSON.parse(await fs.readFile(sessionFile, 'utf8')))
    const immutableIdentityChanged =
      existing.workflowId !== session.workflowId ||
      existing.workbenchPhase !== session.workbenchPhase ||
      existing.stage !== session.stage ||
      existing.sequence !== session.sequence ||
      existing.entryKey !== session.entryKey ||
      existing.threadId !== session.threadId ||
      !sameDevelopmentTarget(existing.developmentTarget, session.developmentTarget)
    if (immutableIdentityChanged) {
      throw new Error('session phase identity is immutable')
    }
    await fs.writeFile(sessionFile, `${JSON.stringify(session, null, 2)}\n`, 'utf8')
    return { ok: true, session: sessionSummary(session) }
  })

  ipcMain.handle('sessions:delete', async (_event, payload = {}) => {
    const sessionFile = getSessionFile(payload.workspaceRoot, payload.editorMode, payload.sessionId)
    await fs.rm(sessionFile, { force: true })
    return { ok: true }
  })

  // 发起新迭代时清空当前工作区的全部会话历史，避免上一版本的对话卡片串入新迭代。
  ipcMain.handle('sessions:clear-workspace', async (_event, payload = {}) => {
    const workspaceSessionRoot = getWorkspaceSessionRoot(payload.workspaceRoot)
    await fs.rm(workspaceSessionRoot, { recursive: true, force: true })
    return { ok: true }
  })
}

/** 注册 Python 认证桥接、公开进度及重新登录所需的 Electron IPC。 */
function setupAuthIpc(): void {
  ipcMain.handle('auth:status', async () => getAuthenticationStatus())
  ipcMain.handle('auth:cloud-request', async (_event, request) => requestAuthenticatedCloud(request))
  ipcMain.handle('auth:cancel', async () => { await clearAuthState(); return { ok: true } })

  ipcMain.handle('auth:login', async (event) => {
    if (isQuitting || event.sender !== loginWindow?.webContents) throw new Error('当前窗口不能发起登录。')
    await loginWithYunxiao((progress) => {
      if (!event.sender.isDestroyed()) event.sender.send('auth:progress', progress)
    })
    if (isQuitting) throw new Error('应用正在退出。')
    if (loginWindow && !loginWindow.isDestroyed()) {
      loginWindow.destroy()
    }
    loginWindow = null
    createMainWindow()
    return { ok: true }
  })

  ipcMain.handle('auth:reauthenticate', async () => {
    await clearAuthState()
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.hide()
    }
    createLoginWindow()
    return { ok: true }
  })
}

type RendererPage = 'index' | 'login'

function loadRendererPage(targetWindow: BrowserWindow, pageName: RendererPage): void {
  const rendererUrl = process.env['ELECTRON_RENDERER_URL']
  if (rendererUrl) {
    const pageUrl =
      pageName === 'index' ? rendererUrl : `${rendererUrl.replace(/\/$/, '')}/${pageName}.html`
    void targetWindow.loadURL(pageUrl)
    return
  }

  void targetWindow.loadFile(join(__dirname, `../renderer/${pageName}.html`))
}

function createMainWindow(): void {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.show()
    mainWindow.focus()
    return
  }

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 720,
    minHeight: 600,
    title: PRODUCT_DISPLAY_NAME,
    backgroundColor: '#f5f7fb',
    show: false,
    autoHideMenuBar: true,
    ...(process.platform === 'linux' ? { icon } : {}),
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      contextIsolation: true,
      nodeIntegration: false,
      additionalArguments: [`--devagentstudio-base-url=${getBackendBaseUrl()}`]
    }
  })

  mainWindow.setMenuBarVisibility(false)
  mainWindow.on('close', (event) => {
    if (isQuitting) return
    event.preventDefault()
    mainWindow?.hide()
  })
  mainWindow.on('closed', () => {
    mainWindow = null
  })
  mainWindow.on('ready-to-show', () => {
    mainWindow?.show()
  })

  mainWindow.webContents.setWindowOpenHandler((details) => {
    shell.openExternal(details.url)
    return { action: 'deny' }
  })

  loadRendererPage(mainWindow, 'index')
}

/** 创建或聚焦带有自定义关闭控件的无边框登录窗口。 */
function createLoginWindow(): void {
  if (loginWindow && !loginWindow.isDestroyed()) {
    loginWindow.show()
    loginWindow.focus()
    return
  }

  loginWindow = new BrowserWindow({
    width: 880,
    height: 620,
    minWidth: 840,
    minHeight: 580,
    title: `${PRODUCT_DISPLAY_NAME} 登录`,
    backgroundColor: '#2f1d49',
    frame: false,
    hasShadow: false,
    show: false,
    autoHideMenuBar: true,
    minimizable: false,
    maximizable: false,
    resizable: false,
    ...(process.platform === 'linux' ? { icon } : {}),
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      contextIsolation: true,
      nodeIntegration: false,
      additionalArguments: [`--devagentstudio-base-url=${getBackendBaseUrl()}`]
    }
  })

  loginWindow.setMenuBarVisibility(false)
  loginWindow.on('close', (event) => {
    if (isQuitting) return
    event.preventDefault()
    loginWindow?.hide()
  })
  loginWindow.on('closed', () => {
    loginWindow = null
  })
  loginWindow.on('ready-to-show', () => {
    loginWindow?.show()
  })

  loadRendererPage(loginWindow, 'login')
}

/** 根据 Python 凭据文件中的有效登录态打开主窗口或登录窗口。 */
async function openAuthenticatedWindow(): Promise<void> {
  if (await hasValidAuthToken()) {
    if (loginWindow && !loginWindow.isDestroyed()) {
      loginWindow.hide()
    }
    createMainWindow()
    return
  }

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.hide()
  }
  createLoginWindow()
}

/** 从托盘发起统一的应用退出流程。 */
function quitFromTray(): void {
  isQuitting = true
  app.quit()
}

function setupTray(): void {
  if (tray) return

  const trayIcon =
    process.platform === 'darwin'
      ? nativeImage.createFromPath(icon).resize({ width: 16, height: 16 })
      : nativeImage.createFromPath(icon)
  if (process.platform === 'darwin') {
    trayIcon.setTemplateImage(true)
  }
  tray = new Tray(trayIcon)
  tray.setToolTip(PRODUCT_DISPLAY_NAME)
  tray.setContextMenu(
    Menu.buildFromTemplate([
      {
        label: '打开主窗口',
        click: () => {
          void openAuthenticatedWindow()
        }
      },
      { type: 'separator' },
      {
        label: '退出',
        click: () => {
          quitFromTray()
        }
      }
    ])
  )
  tray.on('click', () => {
    void openAuthenticatedWindow()
  })
}

/** 在冷启动阶段清除残留认证；失败时提示用户并阻止应用继续初始化。 */
async function clearAuthStateBeforeStartup(): Promise<boolean> {
  try {
    await ensureDevAgentStudioDataDir()
    await revokeLocalCredentials()
    return true
  } catch (error) {
    const authFile = path.join(getDevAgentStudioDataDir(), 'yst-login', 'auth.json')
    console.error('Failed to clear auth token during startup', error)
    dialog.showErrorBox(
      '认证状态清理失败',
      `无法清理本地登录凭证，应用将退出。\n请检查文件权限后重试：\n${authFile}`
    )
    app.quit()
    return false
  }
}

/** 初始化获得单实例锁的主进程，成功后才允许窗口恢复。 */
async function initializePrimaryApplication(): Promise<boolean> {
  installDesignRuntimeProtocol()

  // Set app user model id for windows
  if (process.platform === 'win32') {
    app.setAppUserModelId(process.execPath)
  }

  if (!(await clearAuthStateBeforeStartup())) return false

  // 仅非生产环境开放跨平台开发者工具快捷键。
  if (DEVAGENTSTUDIO_ENV.WORKING_DIR !== WORKSPACE_ARTIFACT_DIR_NAME) {
    app.on('browser-window-created', (_, window) => {
      window.webContents.on('before-input-event', (_event, input) => {
        const isDevToolsShortcut =
          input.key === 'F12' ||
          ((input.control || input.meta) && input.alt && input.key.toLowerCase() === 'i')
        if (isDevToolsShortcut) {
          window.webContents.toggleDevTools()
        }
      })
    })
  }

  // IPC test
  ipcMain.on('ping', () => console.log('pong'))
  const backendBaseUrl = await startBackendService()
  console.log(`DevAgent Studio backend URL: ${backendBaseUrl}`)
  setupApplicationStorageIpc()
  setupApplicationSettingsIpc()
  setupAuthIpc()
  setupBrowserIpc()
  setupProjectPreviewIpc()
  setupWorkspaceIpc()
  setupSessionStorageIpc()
  setupTray()

  await openAuthenticatedWindow()

  app.on('activate', function () {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    void openAuthenticatedWindow()
  })

  return true
}

/** 处理主实例初始化中的非认证清理异常。 */
function handlePrimaryStartupFailure(error: unknown): boolean {
  console.error('Failed to start DevAgent Studio', error)
  app.quit()
  return false
}

/** 第二实例启动时等待主实例完成初始化，然后聚焦当前登录窗口或主窗口。 */
async function focusPrimaryWindowAfterStartup(): Promise<void> {
  const startupPromise = primaryStartupPromise
  if (!startupPromise || !(await startupPromise)) return
  await openAuthenticatedWindow()
}

/** 接收第二实例通知，避免第二进程触碰当前实例的认证文件。 */
function handleSecondInstance(): void {
  void focusPrimaryWindowAfterStartup().catch((error) => {
    console.error('Failed to focus the primary DevAgent Studio window', error)
  })
}

if (!hasSingleInstanceLock) {
  app.quit()
} else {
  app.on('second-instance', handleSecondInstance)
  primaryStartupPromise = app
    .whenReady()
    .then(initializePrimaryApplication)
    .catch(handlePrimaryStartupFailure)
}

let quitCleanupCompleted = false
let quitCleanupStarted = false

/** 在应用退出前清除认证状态并停止本地后端服务。 */
async function cleanupBeforeQuit(): Promise<void> {
  try {
    await shutdownAuthentication()
  } catch (error) {
    console.error('Failed to clear auth token', error)
  }

  try {
    await stopGeneratedProjectPreviewsBeforeQuit()
  } catch (error) {
    console.error('Failed to stop generated project previews', error)
  }

  try {
    await stopBackendService()
  } catch (error) {
    console.error('Failed to stop backend service', error)
  }
  // 后端结束后再清理一次，覆盖强制终止或迟到写入的竞态。
  try {
    await revokeLocalCredentials()
  } catch (error) {
    console.error('认证文件最终清理失败', error)
    dialog.showErrorBox('登录凭据清理失败', '请检查用户数据目录的文件权限。下次启动应用会再次清理残留凭据。')
  }
}

if (hasSingleInstanceLock) {
  app.on('before-quit', (event) => {
    isQuitting = true
    if (quitCleanupCompleted) return

    event.preventDefault()
    if (quitCleanupStarted) return
    quitCleanupStarted = true

    void cleanupBeforeQuit().finally(() => {
      quitCleanupCompleted = true
      app.quit()
    })
  })

  // 普通关闭窗口时保持托盘运行，显式退出由 before-quit 统一清理。
  app.on('window-all-closed', () => {
    // 不在此处退出应用。
  })
}

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
